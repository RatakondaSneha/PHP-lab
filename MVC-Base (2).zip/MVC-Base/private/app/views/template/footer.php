        <script src="/public/js/app.js"></script>
    </body>
</html>