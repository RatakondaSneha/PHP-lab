<h1>Other Index</h1>
<p>This is the other page that is not the default.</p>

<a href="//www.google.ca">Google</a>