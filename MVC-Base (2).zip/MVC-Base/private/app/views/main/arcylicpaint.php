<h1>Arcylic Paints Index</h1>
<p>This is the Arcylic Paints page that is not the default.</p>

<p> Acrylic paint is a fast-drying paint made of pigment suspended in acrylic polymer emulsion.
 Acrylic paints are water-soluble, but become water-resistant when dry. Depending on how much
  the paint is diluted with water, or modified with acrylic gels, mediums, or pastes, the finished 
  acrylic painting can resemble a watercolor, a gouache or an oil painting, or have its own
   unique characteristics not attainable with other media.</p>