<h1>Glass Painting Index</h1>
<p>This is the Glass Painting page that is not the default.</p>

<P>Glass art refers to individual works of art that are substantially or wholly made of glass.
 It ranges in size from monumental works and installation pieces to wall hangings and windows,
  to works of art made in studios and factories, including glass jewelry and tableware. </p>