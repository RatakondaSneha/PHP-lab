<?php
    
    $this->config["database"]["driver"] = "mysql";
    $this->config["database"]["dbhost"] = "";
    $this->config["database"]["dbname"] = "";
    $this->config["database"]["username"] = "baritchie";
    $this->config["database"]["password"] = "";

?>